View more themes from this author: http://alxmedia.se/themes/

You can support the theme author by donating here: 
https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=K54RW72RZM2HN � any amount is always appreciated.


/*  Theme License
/* ------------------------------------ */

The theme itself is nothing but 100% GPLv3. See headers of files for further details.


/*  Font Awesome License
/* ------------------------------------ */

Font License - http://fontawesome.io
License: SIL OFL 1.1
License URI: http://scripts.sil.org/OFL
Copyright: Dave Gandy, http://fontawesome.io

Code License - http://fontawesome.io
License: MIT License
License URI: http://opensource.org/licenses/mit-license.html
Copyright: Dave Gandy, http://fontawesome.io

Brand Icons
All brand icons are trademarks of their respective owners.
The use of these trademarks does not indicate endorsement of the trademark holder by Font Awesome, nor vice versa.


/*  Titillium License
/* ------------------------------------ */

Titillium Font - http://www.campivisivi.net/titillium/
License: SIL OFL 1.1
License URI: http://scripts.sil.org/OFL
Copyright: Accademia di Belle Arti di Urbino, http://campivisivi.net


/*  Theme screenshot images
/* ------------------------------------ */

CC0-licensed (GPL-compatible) images from http://pixabay.com/ and http://unsplash.com/

Left sidebar, top to bottom:

1. unsplash - http://bit.ly/18NNxqe
2. pixabay ID 210801
3. pixabay ID 164985
4. pixabay ID 181744
5. pixabay ID 205220
6. pixabay ID 74570
7. pixabay ID 122694
8. pixabay ID 97433

Content, top to bottom, left to right:

1. pixabay ID 74570
2. unsplash - http://bit.ly/18NNxqe
3. pixabay ID 166705
4. pixabay ID 68827
5. pixabay ID 171732

Right sidebar, top to bottom:

1. pixabay ID 9950
2. pixabay ID 181744
3. pixabay ID 122705
4. pixabay ID 195684
5. pixabay ID 83810
6. pixabay ID 18279


/*  Other Licenses
/* ------------------------------------ */

See headers of files for further details.
